
def showWelcome(name,city):
    print(f'welcome  {name} {city}')


showWelcome('BOA India','Hyderabad')