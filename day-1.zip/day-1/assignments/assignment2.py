
userAge=input('Enter User Age: ')
age= int(userAge)

if age<=0:
    print('Enter Valid Age')
elif age<18:
    print('Not Allowed to Vote')
elif age>=18 and age<80:
    print('Allowed to Vote')
else:
    print('Senior Citizen')
