
projectName='HRMS'
location='Mumbai'
budget=12345
print(f"the projectname is {projectName} \n location is {location} \n budget is {budget}")