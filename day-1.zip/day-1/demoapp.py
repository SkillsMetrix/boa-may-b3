
#declare an array

use_numbers=[]
print(f"Initial Value: {use_numbers}")

data= int(input('How many values you need to add? '))
print(f"You Entered the range Value: {data}")

# take the value

for i in range(data):
    num=int(input (f"Enter {i+1} value: "))
    use_numbers.append(num)
# pring even and odd num

for num in use_numbers:
    if(num%2==0):
        print(f"{num} is even")
    else:
         print(f"{num} is odd")

# print values with positions

print("------printing Even positions---------")

for i in range(0,len(use_numbers),2):
    print(f"Index {i} -> {use_numbers[i]}")

print("------printing Odd positions---------")

for i in range(1,len(use_numbers),2):
    print(f"Index {i} -> {use_numbers[i]}")

# showing addition
result=0
for num in use_numbers:
    result +=num
print(f"the addition is {result}")
