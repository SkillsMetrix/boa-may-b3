
from fastapi import HTTPException,status,APIRouter
from .import schema
from random import randrange

userData=[]

router= APIRouter(tags=["Create , Update ,Delete Operations"])

def searchUser(id):
    for index,value in enumerate(userData):
        if value['id']== id:
            return index



@router.delete('/deleteuser/{id}')
def deleteUser(id:int):
    post=searchUser(id)
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Sorry, User With Given ID not Found")
    userData.pop(post)
    return {'user found and deleted': post}


@router.put('/updateuser/{id}')
def updateUser(id:int,data:schema.User):
    post=searchUser(id)
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Sorry, User With Given ID not Found")
    userValue=data.model_dump()
    userValue['id']=id
    userData[post]=userValue
    
    return {'user found and updated': userValue}


@router.post('/addusers')
def addUser(data:schema.User):
    userValue=data.model_dump()
    userValue['id']=randrange(0,1000)
    userData.append(userValue)
    return {'message':userValue}
