
from fastapi import FastAPI

from . import cud,readdata

app=FastAPI()

app.include_router(cud.router)
app.include_router(readdata.router)