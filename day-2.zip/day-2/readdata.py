
# this file is all about loading the data

from fastapi import HTTPException,status,APIRouter
router=APIRouter(tags=["READ The Data"])

userData=[]

def searchUser(id):
    for index,value in enumerate(userData):
        if value['id']== id:
            return index

@router.get('/loadusers')
def loadUsers():
    return {'message':userData}


@router.get('/loaduser/{id}')
def loadUser(id:int):
    post=searchUser(id)
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Sorry, User With Given ID not Found")
    
    return {'user found': post}







