
from fastapi import FastAPI

app= FastAPI()

@app.get("/")
def loadData():
    return {'message':'welcome to FastAPI Apps'}
@app.get("/boa")
def loadData():
    return {'message':'welcome to Bank Of America Apps'}