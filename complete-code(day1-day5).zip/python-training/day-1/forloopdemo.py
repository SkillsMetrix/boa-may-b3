# declare array 
userNames=['admin','manager','qa']

for uname in userNames:
    print(uname)