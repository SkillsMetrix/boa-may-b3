
a=10
b=5

if a > b:
    print('statement is true')
else:
     print('statement is false')