
from RBI import RBI
class SBI(RBI):
    def openFD(self):
        print('FD opened')
    def depositAmount(self):
        print('deposited in SBI')
    def withdrawAmount(self):
        print('withdraw from SBI')

sbiBank= SBI()
sbiBank.openFD()
sbiBank.depositAmount()
sbiBank.withdrawAmount()