
a= int(input('Enter the value of a : '))
b= int(input('Enter the value of b : '))

c=a+b
print(f"the additions is {c}")