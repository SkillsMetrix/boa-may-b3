
from fastapi import FastAPI
from .database import engine
from . import cud,readdata,models

app=FastAPI()
# this line creates respective table in DB by seeing the model
models.Base.metadata.create_all(bind=engine)

app.include_router(cud.router)
app.include_router(readdata.router)